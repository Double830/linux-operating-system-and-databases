import random
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from database import get_db
from models import User, Character, Monster, CharacterItem, Item
from schemas import DungeonStatus, CombatResult, ItemResponse
from auth import get_current_user

router = APIRouter(prefix="/api/dungeon", tags=["dungeon"])

# 怪物意图
INTENTS = ["attack", "attack", "heavy", "defend", "buff", "debuff"]
INTENT_NAMES = {
    "attack": "⚔️ 普通攻击", "heavy": "💥 蓄力重击",
    "defend": "🛡️ 叠甲防御", "buff": "⚡ 力量增幅", "debuff": "🔮 削弱诅咒",
}
INTENT_ICONS = {"attack": "⚔️", "heavy": "💥", "defend": "🛡️", "buff": "⚡", "debuff": "🔮"}

# 地牢事件权重 (累计概率)
EVENTS = [
    ("monster", 50),      # 50% 怪物
    ("treasure", 65),     # 15% 宝箱
    ("trap", 75),         # 10% 陷阱
    ("fountain", 85),     # 10% 恢复之泉
    ("merchant", 93),     # 8% 神秘商人
    ("shrine", 100),      # 7% 神龛祝福
]


def _generate_intent(monster_name: str, floor: int) -> str:
    weights = [50, 20, 15, 10, 5]
    skill_bonus = min(floor * 2, 30)
    weights[1] += skill_bonus // 2
    weights[2] += skill_bonus // 3
    weights[3] += skill_bonus // 4
    weights[4] += skill_bonus // 5
    pool = []
    for intent, w in zip(INTENTS, weights):
        pool.extend([intent] * w)
    return random.choice(pool)


def _get_character(character_id: int, user: User, db: Session) -> Character:
    char = db.query(Character).filter(Character.id == character_id, Character.user_id == user.id).first()
    if not char:
        raise HTTPException(status_code=404, detail="角色未找到")
    if char.hp <= 0:
        raise HTTPException(status_code=400, detail="你的角色已经阵亡！请创建新角色。")
    return char


def _char_to_response(char: Character):
    from schemas import CharacterResponse
    return CharacterResponse.model_validate(char)


@router.get("/status/{character_id}", response_model=DungeonStatus)
def dungeon_status(character_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    char = _get_character(character_id, user, db)
    status = DungeonStatus(floor=char.dungeon_floor, in_battle=char.in_battle)
    if char.in_battle:
        status.monster = {
            "name": char.battle_monster_name, "hp": char.battle_monster_hp,
            "max_hp": char.battle_monster_max_hp, "attack": char.battle_monster_attack,
            "defense": char.battle_monster_defense, "xp_reward": char.battle_monster_xp,
            "gold_reward": char.battle_monster_gold,
        }
    return status


@router.post("/explore/{character_id}", response_model=CombatResult)
def explore(character_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    char = _get_character(character_id, user, db)

    if char.in_battle:
        raise HTTPException(status_code=400, detail="你已经在战斗中！先击败怪物或逃跑。")

    heal_amount = int(char.max_hp * 0.12)
    char.hp = min(char.hp + heal_amount, char.max_hp)
    db.commit()
    db.refresh(char)

    floor = char.dungeon_floor
    roll = random.randint(1, 100)

    # --- 怪物遭遇 ---
    if roll <= 50:
        available = db.query(Monster).filter(Monster.min_floor <= floor).all()
        if not available:
            raise HTTPException(status_code=500, detail="当前层数没有可用怪物")
        monster = random.choice(available)
        scale = 1.0 + (floor - monster.min_floor) * 0.15

        intent = _generate_intent(monster.name, floor)
        char.in_battle = True
        char.battle_monster_name = f"{monster.emoji} {monster.name}"
        char.battle_monster_hp = int(monster.hp * scale)
        char.battle_monster_max_hp = int(monster.hp * scale)
        char.battle_monster_attack = int(monster.attack * scale)
        char.battle_monster_defense = int(monster.defense * scale)
        char.battle_monster_xp = int(monster.xp_reward * scale)
        char.battle_monster_gold = int(monster.gold_reward * scale)
        char.battle_monster_intent = intent
        db.commit()
        db.refresh(char)
        return CombatResult(
            success=True,
            message=f"⚔️ 在第{floor}层遭遇了 {monster.emoji} **{monster.name}**！",
            log=[
                f"🔍 探索第{floor}层...",
                f"⚔️ 野生的 {monster.name} 出现了！",
                f"❤️ 恢复 {heal_amount} 生命",
                f"{INTENT_ICONS[intent]} 怪物意图: **{INTENT_NAMES[intent]}**",
            ], character=_char_to_response(char),
        )

    # --- 宝箱 ---
    elif roll <= 65:
        gold = random.randint(8, 20) + floor * 5
        char.gold += gold
        loot_item = None
        if random.random() < 0.35:
            pool = db.query(Item).filter(Item.item_type.in_(["weapon", "armor"]), Item.price <= floor * 60 + 50).all()
            if pool:
                loot_item = random.choice(pool)
                existing = db.query(CharacterItem).filter(CharacterItem.character_id == char.id, CharacterItem.item_id == loot_item.id).first()
                if existing: existing.quantity += 1
                else: db.add(CharacterItem(character_id=char.id, item_id=loot_item.id, quantity=1))
        db.commit()
        db.refresh(char)
        log = [f"🔍 探索第{floor}层...", f"📦 发现了一个宝箱！获得 {gold} 金币！"]
        if loot_item: log.append(f"🎁 宝箱里还有 {loot_item.name}！")
        log.append(f"❤️ 恢复 {heal_amount} 生命")
        return CombatResult(success=True, message=f"📦 发现宝箱！+{gold} 金币", log=log, character=_char_to_response(char),
                            loot=[ItemResponse.model_validate(loot_item)] if loot_item else None)

    # --- 陷阱 ---
    elif roll <= 75:
        dmg = max(5, int(char.max_hp * 0.12) + random.randint(-3, 3))
        char.hp = max(0, char.hp - dmg)
        db.commit()
        db.refresh(char)
        log = [f"🔍 探索第{floor}层...", f"💀 踩到了陷阱！受到 {dmg} 点伤害！", f"❤️ 当前生命: {char.hp}/{char.max_hp}"]
        if char.hp <= 0:
            char.hp = 0
            db.commit()
            log.append("☠️ 你死于陷阱...请创建新角色。")
            return CombatResult(success=False, message="💀 被陷阱杀死了...", log=log, character=_char_to_response(char))
        return CombatResult(success=True, message=f"💀 陷阱！-{dmg} HP", log=log, character=_char_to_response(char))

    # --- 恢复之泉 ---
    elif roll <= 85:
        heal = int(char.max_hp * 0.35) + random.randint(5, 15)
        char.hp = min(char.max_hp, char.hp + heal)
        db.commit()
        db.refresh(char)
        log = [f"🔍 探索第{floor}层...", f"💧 发现了恢复之泉！恢复了 {heal} 点生命！", f"❤️ 当前生命: {char.hp}/{char.max_hp}"]
        return CombatResult(success=True, message=f"💧 恢复之泉！+{heal} HP", log=log, character=_char_to_response(char))

    # --- 神秘商人 ---
    elif roll <= 93:
        discount = random.choice([0.5, 0.6, 0.7])
        gold_given = random.randint(5, 15) + floor * 3
        char.gold += gold_given
        db.commit()
        db.refresh(char)
        log = [
            f"🔍 探索第{floor}层...",
            f"🧙 遇到了神秘商人！他给了你 {gold_given} 金币。",
            f"💰 神秘商人: 「商店里的东西现在打 {int(discount*100)} 折，别错过！」",
            f"❤️ 恢复 {heal_amount} 生命"
        ]
        return CombatResult(success=True, message=f"🧙 神秘商人！+{gold_given} 金币", log=log, character=_char_to_response(char))

    # --- 神龛 ---
    else:
        buff_type = random.choice(["attack", "defense", "hp"])
        if buff_type == "attack":
            char.attack += 2
            msg = f"⚡ 攻击力永久 +2！(当前: {char.attack})"
        elif buff_type == "defense":
            char.defense += 2
            msg = f"🛡️ 防御力永久 +2！(当前: {char.defense})"
        else:
            bonus = random.randint(5, 15)
            char.max_hp += bonus
            char.hp = min(char.hp + bonus, char.max_hp)
            msg = f"❤️ 生命上限 +{bonus}！(当前: {char.max_hp})"
        db.commit()
        db.refresh(char)
        log = [f"🔍 探索第{floor}层...", f"⛩️ 发现了一座古老神龛！", msg, f"❤️ 恢复 {heal_amount} 生命"]
        return CombatResult(success=True, message=f"⛩️ 神龛祝福！{msg}", log=log, character=_char_to_response(char))


@router.post("/next-floor/{character_id}", response_model=CombatResult)
def next_floor(character_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    char = _get_character(character_id, user, db)
    if char.in_battle:
        raise HTTPException(status_code=400, detail="请先击败当前怪物再深入探索！")
    char.dungeon_floor += 1
    heal_amount = int(char.max_hp * 0.1)
    char.hp = min(char.hp + heal_amount, char.max_hp)
    db.commit()
    db.refresh(char)
    return CombatResult(
        success=True,
        message=f"⬇️ 下到第{char.dungeon_floor}层，恢复 {heal_amount} 生命。",
        log=[f"⬇️ 向地牢深处前进...", f"📍 第{char.dungeon_floor}层", f"❤️ +{heal_amount} HP ({char.hp}/{char.max_hp})"],
        character=_char_to_response(char),
    )
