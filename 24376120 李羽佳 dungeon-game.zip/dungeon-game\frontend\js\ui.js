// UI模块 — 导航、各页面渲染
let currentScreen = 'auth';

function showScreen(name) {
    currentScreen = name;
    document.querySelectorAll('.game-screen').forEach(s => s.classList.remove('active'));
    const el = document.getElementById(`screen-${name}`);
    if (el) el.classList.add('active');
}

function navigateTo(screen) {
    switch (screen) {
        case 'game':
            showScreen('game');
            refreshCharPanel();
            // 如果战后选项还活跃，恢复显示
            if (typeof restorePostBattleOptions === 'function') {
                restorePostBattleOptions();
            }
            break;
        case 'inventory':
            showInventory();
            break;
        case 'shop':
            showShop();
            break;
        case 'leaderboard':
            showLeaderboard();
            break;
    }
}

function addLogLine(text, cls) {
    const logEl = document.getElementById('game-log');
    const line = document.createElement('div');
    line.className = `log-line ${cls || ''}`;
    line.innerHTML = text.replace(/\*\*(.*?)\*\*/g, '<strong style="color:var(--gold-bright)">$1</strong>');
    logEl.appendChild(line);
    logEl.scrollTop = logEl.scrollHeight;
}

// --- 背包页面 ---
async function showInventory() {
    if (!activeCharId) return;
    showScreen('inventory');

    try {
        const items = await API.get(`/inventory/${activeCharId}`);
        const listEl = document.getElementById('inventory-list');

        if (items.length === 0) {
            listEl.innerHTML = '<p style="color:var(--text-dim);text-align:center">背包空空如也。去商店买些装备吧！</p>';
        } else {
            listEl.innerHTML = items.map(ci => `
                <div class="inv-item ${ci.equipped ? 'equipped' : ''}">
                    <div class="item-info">
                        <h4 class="rarity-${ci.item.rarity}">
                            ${ci.item.name}
                            ${ci.equipped ? '<span style="color:var(--gold)">✅ 已装备</span>' : ''}
                        </h4>
                        <p>${ci.item.description} | ${ci.item.item_type === 'weapon' ? '武器' : ci.item.item_type === 'armor' ? '护甲' : '药水'} | ${ci.item.rarity}</p>
                        ${ci.quantity > 1 ? `<p>数量: ${ci.quantity}</p>` : ''}
                    </div>
                    <div>
                        ${!ci.equipped && ci.item.item_type !== 'potion'
                            ? `<button class="btn-primary" onclick="equipItem(${ci.id})">装备</button>`
                            : ''}
                        ${ci.equipped
                            ? `<button class="btn-danger" onclick="unequipItem(${ci.id})">卸下</button>`
                            : ''}
                    </div>
                </div>
            `).join('');
        }
    } catch (err) {
        alert(err.message);
    }
}

async function equipItem(inventoryId) {
    try {
        await API.post(`/inventory/equip/${activeCharId}/${inventoryId}`);
        showInventory();
    } catch (err) { alert(err.message); }
}

async function unequipItem(inventoryId) {
    try {
        await API.post(`/inventory/unequip/${activeCharId}/${inventoryId}`);
        showInventory();
    } catch (err) { alert(err.message); }
}

// --- 商店页面 ---
async function showShop() {
    if (!activeCharId) return;
    showScreen('shop');

    try {
        const [items, char] = await Promise.all([
            API.get('/shop'),
            API.get(`/characters/${activeCharId}`),
        ]);

        document.getElementById('shop-gold').innerHTML = `💰 你的金币: <strong style="color:var(--gold-bright)">${char.gold}</strong>`;

        document.getElementById('shop-list').innerHTML = items.map(item => `
            <div class="shop-item">
                <div>
                    <h4 class="rarity-${item.rarity}">${item.name}</h4>
                    <p style="color:var(--text-dim);font-size:0.85em">${item.description}</p>
                </div>
                <div style="text-align:right">
                    <p class="price">💰 ${item.price}g</p>
                    <button class="btn-primary" onclick="buyItem(${item.id})"
                        ${char.gold < item.price ? 'disabled style="opacity:0.4"' : ''}>
                        购买
                    </button>
                </div>
            </div>
        `).join('');
    } catch (err) {
        alert(err.message);
    }
}

async function buyItem(itemId) {
    try {
        await API.post(`/shop/buy/${activeCharId}/${itemId}`);
        showShop();
    } catch (err) { alert(err.message); }
}

// --- 排行榜页面 ---
async function showLeaderboard() {
    if (!activeCharId) return;
    showScreen('leaderboard');

    try {
        const entries = await API.get('/leaderboard?limit=20');
        document.getElementById('leaderboard-list').innerHTML = `
            <div class="leaderboard-row header">
                <span>#</span><span>角色</span><span>职业</span><span>等级</span><span>层数</span>
            </div>
            ${entries.map(e => `
                <div class="leaderboard-row">
                    <span class="rank">${e.rank <= 3 ? ['🥇','🥈','🥉'][e.rank-1] : `#${e.rank}`}</span>
                    <span>
                        <strong style="color:var(--text-bright)">${e.character_name}</strong>
                        <br><small style="color:var(--text-dim)">${e.username}</small>
                    </span>
                    <span class="class-${e.char_class}">${e.char_class === 'warrior' ? '战士' : e.char_class === 'mage' ? '法师' : '盗贼'}</span>
                    <span>⭐ ${e.level}</span>
                    <span>📍 ${e.dungeon_floor}</span>
                </div>
            `).join('')}
            ${entries.length === 0 ? '<p style="text-align:center;color:var(--text-dim)">还没有冒险者上榜！</p>' : ''}
        `;
    } catch (err) {
        alert(err.message);
    }
}
