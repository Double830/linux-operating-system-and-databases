from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from database import get_db
from models import User, Character, CharacterItem, Item
from schemas import CharacterCreate, CharacterResponse
from auth import get_current_user

router = APIRouter(prefix="/api/characters", tags=["characters"])

CLASS_STATS = {
    "warrior": {"max_hp": 125, "attack": 12, "defense": 16, "name": "战士", "description": "⚔️ 坦克型前排，生存能力极强"},
    "mage": {"max_hp": 65, "attack": 18, "defense": 6, "name": "法师", "description": "🔮 最高输出，但极其脆弱，需要保护"},
    "rogue": {"max_hp": 90, "attack": 14, "defense": 12, "name": "盗贼", "description": "🗡️ 均衡型，暴击20%+灵活技能"},
}

# 各职业初始武器
STARTER_WEAPONS = {
    "warrior": "精铁长剑",
    "mage": "学徒法杖",
    "rogue": "暗影匕首",
}


@router.get("/classes")
def get_classes():
    return CLASS_STATS


@router.post("", response_model=CharacterResponse)
def create_character(data: CharacterCreate, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if data.char_class not in CLASS_STATS:
        raise HTTPException(status_code=400, detail="无效的职业。请选择 warrior、mage 或 rogue。")

    stats = CLASS_STATS[data.char_class]
    character = Character(
        user_id=user.id,
        name=data.name,
        char_class=data.char_class,
        max_hp=stats["max_hp"],
        hp=stats["max_hp"],
        attack=stats["attack"],
        defense=stats["defense"],
    )
    db.add(character)
    db.flush()  # 获取 character.id

    # 给角色发放初始武器
    weapon_name = STARTER_WEAPONS.get(data.char_class)
    if weapon_name:
        weapon = db.query(Item).filter(Item.name == weapon_name).first()
        if weapon:
            db.add(CharacterItem(character_id=character.id, item_id=weapon.id, equipped=True, quantity=1))
            # 初始武器属性加成
            character.attack += weapon.stat_bonus

    db.commit()
    db.refresh(character)
    return character


@router.get("/mine", response_model=list[CharacterResponse])
def my_characters(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return db.query(Character).filter(Character.user_id == user.id).all()


@router.get("/{character_id}", response_model=CharacterResponse)
def get_character(character_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    character = db.query(Character).filter(Character.id == character_id, Character.user_id == user.id).first()
    if not character:
        raise HTTPException(status_code=404, detail="角色未找到")
    return character


@router.delete("/{character_id}")
def delete_character(character_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    character = db.query(Character).filter(Character.id == character_id, Character.user_id == user.id).first()
    if not character:
        raise HTTPException(status_code=404, detail="角色未找到")
    db.delete(character)
    db.commit()
    return {"message": "角色已删除"}
