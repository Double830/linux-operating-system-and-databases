import random
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session, joinedload
from database import get_db
from models import User, Character, BattleLog, CharacterItem, Item
from schemas import CombatAction, CombatResult, CharacterResponse, ItemResponse, AttackAction
from auth import get_current_user

router = APIRouter(prefix="/api/combat", tags=["combat"])

XP_PER_LEVEL = 100

# ========== 武器技能表 ==========
# 每个武器有 3 个技能，各有不同的触发概率、伤害倍率和状态效果
WEAPON_SKILLS = {
    # ===== 战士武器系 =====
    "生锈的铁剑": [
        {"name": "劈砍", "icon": "⚔️", "prob": 80, "dmg_mult": 0.7, "fail_dmg": 0.2, "effect": None, "desc": "基础攻击"},
        {"name": "用力挥击", "icon": "💥", "prob": 40, "dmg_mult": 1.2, "fail_dmg": 0.2, "effect": None, "desc": ""},
        {"name": "剑柄敲击", "icon": "🔨", "prob": 35, "dmg_mult": 0.4, "fail_dmg": 0.1, "effect": "stun", "desc": ""},
    ],
    "精铁长剑": [
        {"name": "横斩", "icon": "⚔️", "prob": 90, "dmg_mult": 1.0, "fail_dmg": 0.3, "effect": None, "desc": "稳定输出"},
        {"name": "猛击", "icon": "💥", "prob": 50, "dmg_mult": 1.8, "fail_dmg": 0.3, "effect": None, "desc": "重击"},
        {"name": "盾击", "icon": "🛡️", "prob": 55, "dmg_mult": 0.8, "fail_dmg": 0.2, "effect": "stun", "desc": "眩晕1回合"},
    ],
    "寒钢利刃": [
        {"name": "精准刺击", "icon": "⚔️", "prob": 85, "dmg_mult": 1.2, "fail_dmg": 0.3, "effect": None, "desc": ""},
        {"name": "旋风斩", "icon": "🌪️", "prob": 55, "dmg_mult": 1.7, "fail_dmg": 0.3, "effect": None, "desc": ""},
        {"name": "破甲斩", "icon": "💔", "prob": 45, "dmg_mult": 1.0, "fail_dmg": 0.2, "effect": "vulnerable", "desc": "易伤"},
    ],
    "烈焰之舌": [
        {"name": "火焰斩", "icon": "🔥", "prob": 85, "dmg_mult": 1.3, "fail_dmg": 0.4, "effect": None, "desc": ""},
        {"name": "烈焰风暴", "icon": "🌋", "prob": 50, "dmg_mult": 2.0, "fail_dmg": 0.3, "effect": None, "desc": ""},
        {"name": "灼热烙印", "icon": "♨️", "prob": 45, "dmg_mult": 1.1, "fail_dmg": 0.2, "effect": "poison", "desc": "灼烧中毒"},
    ],
    "屠龙宝刀": [
        {"name": "龙斩", "icon": "🐉", "prob": 90, "dmg_mult": 1.5, "fail_dmg": 0.4, "effect": None, "desc": ""},
        {"name": "天崩地裂", "icon": "💥", "prob": 55, "dmg_mult": 2.5, "fail_dmg": 0.4, "effect": None, "desc": ""},
        {"name": "龙威震慑", "icon": "👑", "prob": 50, "dmg_mult": 1.2, "fail_dmg": 0.2, "effect": "stun", "desc": "眩晕2回合"},
    ],
    # ===== 法师武器系 =====
    "学徒法杖": [
        {"name": "火球术", "icon": "🔥", "prob": 85, "dmg_mult": 1.0, "fail_dmg": 0.3, "effect": None, "desc": ""},
        {"name": "冰霜箭", "icon": "❄️", "prob": 55, "dmg_mult": 1.3, "fail_dmg": 0.3, "effect": "slow", "desc": "减速"},
        {"name": "奥术飞弹", "icon": "✨", "prob": 35, "dmg_mult": 1.7, "fail_dmg": 0.2, "effect": None, "desc": "爆发"},
    ],
    # ===== 盗贼武器系 =====
    "暗影匕首": [
        {"name": "刺击", "icon": "🗡️", "prob": 85, "dmg_mult": 1.0, "fail_dmg": 0.3, "effect": None, "desc": ""},
        {"name": "要害攻击", "icon": "🎯", "prob": 50, "dmg_mult": 1.6, "fail_dmg": 0.3, "effect": "vulnerable", "desc": "易伤"},
        {"name": "致命毒药", "icon": "☠️", "prob": 45, "dmg_mult": 1.2, "fail_dmg": 0.2, "effect": "poison", "desc": "中毒"},
    ],
}

# 商店武器技能（按稀有度自动生成）
RARITY_SKILLS = {
    "common": [
        {"name": "斩击", "icon": "⚔️", "prob": 80, "dmg_mult": 1.0, "fail_dmg": 0.3, "effect": None, "desc": ""},
        {"name": "重击", "icon": "💥", "prob": 45, "dmg_mult": 1.5, "fail_dmg": 0.3, "effect": None, "desc": ""},
        {"name": "破甲", "icon": "🔨", "prob": 40, "dmg_mult": 0.8, "fail_dmg": 0.2, "effect": "vulnerable", "desc": ""},
    ],
    "uncommon": [
        {"name": "精准打击", "icon": "⚔️", "prob": 85, "dmg_mult": 1.1, "fail_dmg": 0.3, "effect": None, "desc": ""},
        {"name": "旋风斩", "icon": "🌪️", "prob": 50, "dmg_mult": 1.7, "fail_dmg": 0.3, "effect": None, "desc": ""},
        {"name": "碎甲", "icon": "💔", "prob": 45, "dmg_mult": 1.0, "fail_dmg": 0.2, "effect": "vulnerable", "desc": ""},
    ],
    "rare": [
        {"name": "烈焰斩", "icon": "🔥", "prob": 85, "dmg_mult": 1.3, "fail_dmg": 0.3, "effect": None, "desc": ""},
        {"name": "雷霆一击", "icon": "⚡", "prob": 55, "dmg_mult": 2.0, "fail_dmg": 0.3, "effect": None, "desc": ""},
        {"name": "冰封", "icon": "❄️", "prob": 45, "dmg_mult": 1.1, "fail_dmg": 0.2, "effect": "slow", "desc": ""},
    ],
    "epic": [
        {"name": "神圣裁决", "icon": "✨", "prob": 90, "dmg_mult": 1.4, "fail_dmg": 0.4, "effect": None, "desc": ""},
        {"name": "末日风暴", "icon": "🌋", "prob": 60, "dmg_mult": 2.2, "fail_dmg": 0.3, "effect": None, "desc": ""},
        {"name": "时间静止", "icon": "⏳", "prob": 50, "dmg_mult": 1.2, "fail_dmg": 0.2, "effect": "stun", "desc": ""},
    ],
}

STATUS_NAMES = {
    "stun": "眩晕",
    "vulnerable": "易伤",
    "poison": "中毒",
    "slow": "减速",
}

INTENT_NAMES = {
    "attack": "⚔️ 普通攻击",
    "heavy": "💥 蓄力重击",
    "defend": "🛡️ 叠甲防御",
    "buff": "⚡ 力量增幅",
    "debuff": "🔮 削弱诅咒",
}
INTENT_ICONS = {
    "attack": "⚔️",
    "heavy": "💥",
    "defend": "🛡️",
    "buff": "⚡",
    "debuff": "🔮",
}


def _get_weapon_skills(weapon_name: str, rarity: str = "common") -> list:
    """获取武器的技能列表。知名武器用专属技能，否则按稀有度生成。"""
    if weapon_name in WEAPON_SKILLS:
        return WEAPON_SKILLS[weapon_name]
    return RARITY_SKILLS.get(rarity, RARITY_SKILLS["common"])


def _get_equipped_weapon(char: Character, db: Session):
    """获取角色当前装备的武器。"""
    ci = db.query(CharacterItem).options(joinedload(CharacterItem.item)).filter(
        CharacterItem.character_id == char.id,
        CharacterItem.equipped == True,
        Item.item_type == "weapon",
    ).first()
    return ci


def _roll_skill(skills: list) -> dict:
    """按概率掷骰子，选择一个触发的技能。返回触发的技能或 None（普攻）。"""
    # 按概率从高到低依次判定
    for skill in skills:
        if random.randint(1, 100) <= skill["prob"]:
            return skill
    return None  # 所有技能都没触发，使用普通攻击


def _apply_status(statuses: str, new_status: str) -> str:
    """添加状态效果（去重）。"""
    current = [s for s in (statuses or "").split(",") if s]
    if new_status not in current:
        current.append(new_status)
    return ",".join(current)


def _consume_statuses(statuses: str) -> str:
    """消耗回合性状态（stun 只持续1回合）。"""
    if not statuses:
        return ""
    current = [s for s in statuses.split(",") if s]
    # stun 持续1回合后自动清除
    remaining = [s for s in current if s != "stun"]
    return ",".join(remaining)


def _generate_next_intent(floor: int) -> str:
    intents_pool = []
    weights = [50, 20, 15, 10, 5]
    skill_bonus = min(floor * 2, 30)
    weights[1] += skill_bonus // 2
    weights[2] += skill_bonus // 3
    weights[3] += skill_bonus // 4
    weights[4] += skill_bonus // 5
    for intent, w in zip(["attack", "heavy", "defend", "buff", "debuff"], weights):
        intents_pool.extend([intent] * w)
    return random.choice(intents_pool)


def _monster_act(char: Character, log: list) -> None:
    """怪物行动（受状态效果影响）。"""
    statuses = [s for s in (char.battle_monster_status or "").split(",") if s]

    # 检查眩晕
    if "stun" in statuses:
        log.append("😵 怪物被眩晕，无法行动！")
        return

    intent = char.battle_monster_intent or "attack"
    base_dmg = char.battle_monster_attack

    # 减速：伤害减半
    if "slow" in statuses:
        base_dmg = max(1, base_dmg // 2)
        log.append("🐌 怪物被减速，攻击力降低！")

    icon = INTENT_ICONS.get(intent, "⚔️")

    if intent == "attack":
        dmg = max(1, base_dmg - char.defense // 2 + random.randint(-2, 2))
        char.hp = max(0, char.hp - dmg)
        log.append(f"{icon} 怪物使用普通攻击，造成 {dmg} 点伤害！")

    elif intent == "heavy":
        dmg = max(1, int(base_dmg * 1.5) - char.defense // 3 + random.randint(-1, 1))
        char.hp = max(0, char.hp - dmg)
        log.append(f"{icon} 怪物蓄力后猛击！造成 {dmg} 点伤害！")

    elif intent == "defend":
        char.battle_monster_defense += max(2, char.battle_monster_defense // 4)
        log.append(f"{icon} 怪物进入防御姿态，防御力提升了！")
        dmg = max(1, (base_dmg - char.defense) // 2)
        char.hp = max(0, char.hp - dmg)
        log.append(f"   同时造成 {dmg} 点伤害。")

    elif intent == "buff":
        char.battle_monster_attack += max(2, char.battle_monster_attack // 5)
        log.append(f"{icon} 怪物怒吼一声，攻击力提升了！")
        dmg = max(1, base_dmg - char.defense // 2)
        char.hp = max(0, char.hp - dmg)
        log.append(f"   同时造成 {dmg} 点伤害。")

    elif intent == "debuff":
        debuff_amount = max(1, char.defense // 5)
        char.defense = max(0, char.defense - debuff_amount)
        log.append(f"{icon} 怪物施放诅咒，你的防御力降低 {debuff_amount} 点！")
        dmg = max(1, base_dmg - char.defense // 2)
        char.hp = max(0, char.hp - dmg)
        log.append(f"   同时造成 {dmg} 点伤害。")

    else:
        dmg = max(1, base_dmg - char.defense // 2 + random.randint(-2, 2))
        char.hp = max(0, char.hp - dmg)
        log.append(f"{icon} 怪物攻击，造成 {dmg} 点伤害！")


def _get_character_in_battle(character_id: int, user: User, db: Session) -> Character:
    from routers.dungeon import _get_character
    char = _get_character(character_id, user, db)
    if not char.in_battle:
        raise HTTPException(status_code=400, detail="你尚未进入战斗！请先探索地牢。")
    return char


def _char_to_response(char: Character):
    return CharacterResponse.model_validate(char)


@router.get("/skills/{character_id}")
def get_skills(character_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """获取角色当前可用技能列表。"""
    char = _get_character_in_battle(character_id, user, db)
    weapon_ci = _get_equipped_weapon(char, db)
    if weapon_ci:
        weapon = weapon_ci.item
        skills = _get_weapon_skills(weapon.name, weapon.rarity)
        # 计算预估伤害
        for s in skills:
            s["est_dmg"] = max(1, int(char.attack * s["dmg_mult"]))
            s["est_fail"] = max(1, int(char.attack * s.get("fail_dmg", 0.3)))
        return {"weapon": weapon.name, "skills": skills, "attack": char.attack}
    else:
        skills = [
            {"name": "拳击", "icon": "👊", "dmg_mult": 0.5, "fail_dmg": 0.2, "effect": None, "desc": "用拳头攻击"},
            {"name": "头槌", "icon": "💢", "dmg_mult": 0.7, "fail_dmg": 0.2, "effect": None, "desc": "用头撞击"},
            {"name": "踢击", "icon": "🦵", "dmg_mult": 0.6, "fail_dmg": 0.2, "effect": "slow", "desc": "踢中要害"},
        ]
        for s in skills:
            s["est_dmg"] = max(1, int(char.attack * s["dmg_mult"]))
            s["est_fail"] = max(1, int(char.attack * s.get("fail_dmg", 0.2)))
        return {"weapon": "空手", "skills": skills, "attack": char.attack}


@router.post("/attack/{character_id}", response_model=CombatResult)
def attack(character_id: int, body: AttackAction, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    char = _get_character_in_battle(character_id, user, db)
    log = []

    # 获取装备武器和技能
    weapon_ci = _get_equipped_weapon(char, db)
    if weapon_ci:
        weapon = weapon_ci.item
        skills = _get_weapon_skills(weapon.name, weapon.rarity)
    else:
        skills = [{"name": "拳击", "icon": "👊", "dmg_mult": 0.5, "effect": None, "desc": ""}]

    # 使用玩家选择的技能（默认第一个）
    skill_idx = body.skill_index if body else 0
    skill_idx = max(0, min(skill_idx, len(skills) - 1))
    chosen = skills[skill_idx]

    # 掷骰子判断成功/失败
    roll = random.randint(1, 100)
    success = roll <= chosen["prob"]

    # 易伤加成
    statuses = [s for s in (char.battle_monster_status or "").split(",") if s]
    vuln_mult = 1.5 if "vulnerable" in statuses else 1.0
    if vuln_mult > 1.0:
        log.append("💔 怪物处于易伤状态，受到伤害+50%！")

    # 盗贼暴击
    crit = char.char_class == "rogue" and random.random() < 0.20

    if success:
        base_dmg = max(1, int(char.attack * chosen["dmg_mult"]) - char.battle_monster_defense // 2)
        base_dmg = int(base_dmg * vuln_mult)
        variance = random.randint(-1, 2)
        dmg = max(1, base_dmg + variance)

        if crit:
            dmg = int(dmg * 2)
            log.append(f"🎯 暴击！{chosen['icon']} **{chosen['name']}** 成功！造成 {dmg} 点伤害！")
        else:
            log.append(f"{chosen['icon']} **{chosen['name']}** 成功！（判定{roll}≤{chosen['prob']}）造成 {dmg} 点伤害。")

        # 应用状态效果
        if chosen.get("effect"):
            char.battle_monster_status = _apply_status(char.battle_monster_status, chosen["effect"])
            status_name = STATUS_NAMES.get(chosen["effect"], chosen["effect"])
            log.append(f"✨ 附加效果: **{status_name}**！")
    else:
        fail_mult = chosen.get("fail_dmg", 0.3)
        dmg = max(1, int(char.attack * fail_mult) - char.battle_monster_defense // 2 + random.randint(-1, 1))
        dmg = max(1, int(dmg * vuln_mult))
        log.append(f"💨 {chosen['icon']} **{chosen['name']}** 失败...（判定{roll}>{chosen['prob']}）仅造成 {dmg} 点伤害。")

    char.battle_monster_hp = max(0, char.battle_monster_hp - dmg)

    # 中毒伤害（持续伤害）
    if "poison" in statuses and char.battle_monster_hp > 0:
        poison_dmg = max(1, char.battle_monster_max_hp // 20)
        char.battle_monster_hp = max(0, char.battle_monster_hp - poison_dmg)
        log.append(f"☠️ 毒素发作，怪物额外损失 {poison_dmg} 点生命！")

    # 消耗回合性状态
    old_statuses = char.battle_monster_status
    char.battle_monster_status = _consume_statuses(char.battle_monster_status)
    if old_statuses != char.battle_monster_status:
        removed = [STATUS_NAMES.get(s, s) for s in (old_statuses or "").split(",") if s and s not in (char.battle_monster_status or "")]
        if removed:
            log.append(f"🔄 怪物状态解除: {', '.join(removed)}")

    if char.battle_monster_hp <= 0:
        return _end_battle(char, "win", log, db)

    # 怪物行动
    _monster_act(char, log)

    if char.hp <= 0:
        char.hp = 0
        return _end_battle(char, "lose", log, db)

    # 生成怪物下回合意图
    next_intent = _generate_next_intent(char.dungeon_floor)
    char.battle_monster_intent = next_intent
    db.commit()
    db.refresh(char)

    return CombatResult(
        success=True,
        message="战斗继续！",
        log=log + [
            f"❤️ 你的生命: {char.hp}/{char.max_hp}",
            f"💔 怪物生命: {char.battle_monster_hp}/{char.battle_monster_max_hp}",
            f"{INTENT_ICONS[next_intent]} 怪物下回合意图: **{INTENT_NAMES[next_intent]}**",
            "",
            "⚡ **轮到你了！** 请选择: 攻击 / 防御 / 使用药水 / 逃跑",
        ],
        character=_char_to_response(char),
    )


@router.post("/defend/{character_id}", response_model=CombatResult)
def defend(character_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    char = _get_character_in_battle(character_id, user, db)
    log = [f"🛡️ 你摆出防御姿态！本回合受到的伤害减少。"]

    old_def = char.defense
    char.defense = char.defense + 10
    _monster_act(char, log)
    char.defense = old_def

    if char.char_class == "warrior":
        heal_def = max(0, min(4, char.max_hp // 10))
        char.hp = min(char.max_hp, char.hp + heal_def)
        if heal_def > 0:
            log.append(f"💪 战士的坚韧恢复了 {heal_def} 点生命！")

    log.append(f"❤️ 你的生命: {char.hp}/{char.max_hp}")

    # 消耗怪物回合状态
    char.battle_monster_status = _consume_statuses(char.battle_monster_status)

    if char.hp <= 0:
        char.hp = 0
        return _end_battle(char, "lose", log, db)

    next_intent = _generate_next_intent(char.dungeon_floor)
    char.battle_monster_intent = next_intent
    db.commit()
    db.refresh(char)

    return CombatResult(
        success=True,
        message="防御成功！",
        log=log + [
            f"{INTENT_ICONS[next_intent]} 怪物下回合意图: **{INTENT_NAMES[next_intent]}**",
            "",
            "⚡ **轮到你了！** 请选择: 攻击 / 防御 / 使用药水 / 逃跑",
        ],
        character=_char_to_response(char),
    )


@router.post("/flee/{character_id}", response_model=CombatResult)
def flee(character_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    char = _get_character_in_battle(character_id, user, db)
    log = []

    flee_chance = 0.85 if char.char_class == "rogue" else 0.60
    if random.random() < flee_chance:
        log.append("🏃 你成功逃跑了！")
        return _end_battle(char, "flee", log, db, success_message="安全逃脱！")
    else:
        _monster_act(char, log)
        log.insert(0, "❌ 逃跑失败！")

        char.battle_monster_status = _consume_statuses(char.battle_monster_status)

        if char.hp <= 0:
            char.hp = 0
            return _end_battle(char, "lose", log, db)

        next_intent = _generate_next_intent(char.dungeon_floor)
        char.battle_monster_intent = next_intent
        db.commit()
        db.refresh(char)
        return CombatResult(
            success=True,
            message="逃跑失败！",
            log=log + [
                f"❤️ 你的生命: {char.hp}/{char.max_hp}",
                f"{INTENT_ICONS[next_intent]} 怪物下回合意图: **{INTENT_NAMES[next_intent]}**",
                "",
                "⚡ **轮到你了！** 请选择: 攻击 / 防御 / 使用药水 / 逃跑",
            ],
            character=_char_to_response(char),
        )


@router.post("/use-potion/{character_id}", response_model=CombatResult)
def use_potion(character_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    char = _get_character_in_battle(character_id, user, db)
    log = []

    potion_item = db.query(CharacterItem).join(Item).filter(
        CharacterItem.character_id == char.id,
        Item.item_type == "potion",
        CharacterItem.quantity > 0,
    ).order_by(Item.stat_bonus.desc()).first()

    if not potion_item:
        raise HTTPException(status_code=400, detail="背包中没有药水！去商店买一些吧。")

    potion = potion_item.item
    heal_amount = potion.stat_bonus if potion.stat_bonus < 999 else char.max_hp
    char.hp = min(char.max_hp, char.hp + heal_amount)
    log.append(f"🧪 你使用了 {potion.name}！恢复了 {heal_amount} 点生命")

    potion_item.quantity -= 1
    if potion_item.quantity <= 0:
        db.delete(potion_item)

    db.commit()

    _monster_act(char, log)
    log.append(f"❤️ 你的生命: {char.hp}/{char.max_hp}")

    char.battle_monster_status = _consume_statuses(char.battle_monster_status)

    if char.hp <= 0:
        char.hp = 0
        return _end_battle(char, "lose", log, db)

    next_intent = _generate_next_intent(char.dungeon_floor)
    char.battle_monster_intent = next_intent
    db.commit()
    db.refresh(char)

    return CombatResult(
        success=True,
        message="使用了药水！",
        log=log + [
            f"{INTENT_ICONS[next_intent]} 怪物下回合意图: **{INTENT_NAMES[next_intent]}**",
            "",
            "⚡ **轮到你了！** 请选择: 攻击 / 防御 / 使用药水 / 逃跑",
        ],
        character=_char_to_response(char),
    )


def _end_battle(char: Character, result: str, log: list, db: Session, success_message: str = None):
    loot_items = []
    leveled_up = False

    monster_name = char.battle_monster_name
    monster_xp = char.battle_monster_xp
    monster_gold = char.battle_monster_gold

    char.in_battle = False
    char.battle_monster_name = None
    char.battle_monster_hp = None
    char.battle_monster_max_hp = None
    char.battle_monster_attack = None
    char.battle_monster_defense = None
    char.battle_monster_xp = None
    char.battle_monster_gold = None
    char.battle_monster_intent = None
    char.battle_monster_status = None

    if result == "win":
        log.append(f"🎉 你击败了 {monster_name}！")
        char.xp += monster_xp
        char.gold += monster_gold
        log.append(f"✨ +{monster_xp} 经验 | +{monster_gold} 金币")

        needed = char.level * XP_PER_LEVEL
        while char.xp >= needed:
            char.level += 1
            char.xp -= needed
            char.max_hp += 10
            char.hp = char.max_hp
            char.attack += 3
            char.defense += 2
            needed = char.level * XP_PER_LEVEL
            log.append(f"🆙 升级了！你现在是 {char.level} 级！")
            log.append(f"   生命上限+10 | 攻击+3 | 防御+2")
            leveled_up = True

        if random.random() < 0.30:
            loot_pool = db.query(Item).filter(
                Item.item_type.in_(["weapon", "armor"]),
                Item.price <= char.level * 60 + 50,
            ).all()
            if loot_pool:
                loot_item = random.choice(loot_pool)
                existing = db.query(CharacterItem).filter(
                    CharacterItem.character_id == char.id,
                    CharacterItem.item_id == loot_item.id,
                ).first()
                if existing:
                    existing.quantity += 1
                else:
                    db.add(CharacterItem(character_id=char.id, item_id=loot_item.id, quantity=1))
                log.append(f"🎁 掉落装备: {loot_item.name}（{loot_item.rarity}）！")
                loot_items.append(loot_item)

    elif result == "lose":
        log.append(f"💀 你被 {monster_name} 击败了！")
        log.append("☠️ 你的角色阵亡了。请创建新角色继续冒险。")
        char.hp = 0

    elif result == "flee":
        log.append(f"🏃 你从 {monster_name} 面前逃走了。")

    db.add(BattleLog(character_id=char.id, monster_name=monster_name, result=result))
    db.commit()
    db.refresh(char)

    return CombatResult(
        success=result != "lose",
        message=success_message or (f"战胜了 {monster_name}！" if result == "win" else f"被 {monster_name} 击败..."),
        log=log,
        character=_char_to_response(char),
        loot=[ItemResponse.model_validate(li) for li in loot_items] if loot_items else None,
        leveled_up=leveled_up,
    )
