// 战斗模块 — 攻击、防御、逃跑、药水、战后选项
let postBattleActive = false;
let lastCombatResult = null;
let currentSkills = [];  // 当前武器技能列表

// 攻击：使用指定技能
async function attackWithSkill(skillIndex) {
    if (!activeCharId) return;
    try {
        const result = await API.post(`/combat/attack/${activeCharId}`, { skill_index: skillIndex });
        processCombatResult(result);
    } catch (err) {
        addLogLine(`❌ ${err.message}`, 'danger');
    }
}

// 加载武器技能并显示按钮
async function loadSkills() {
    if (!activeCharId) return;
    try {
        const data = await API.get(`/combat/skills/${activeCharId}`);
        currentSkills = data.skills;
        const effNames = { stun: '眩晕', vulnerable: '易伤', poison: '中毒', slow: '减速' };
        const container = document.getElementById('skill-buttons');
        container.innerHTML = currentSkills.map((s, i) => {
            const atk = data.attack || 10;
            const estDmg = s.est_dmg || Math.floor(atk * s.dmg_mult);
            const estFail = s.est_fail || Math.floor(atk * (s.fail_dmg || 0.3));
            let effectTag = '';
            if (s.effect) {
                effectTag = `<span style="color:var(--purple-bright)">+${effNames[s.effect] || s.effect}</span>`;
            }
            return `<button class="btn-combat" onclick="attackWithSkill(${i})"
                style="font-size:1em;background:var(--bg-dark);border-color:var(--gold);color:var(--gold-bright);padding:8px 12px;text-align:center;min-width:100px">
                <div style="font-size:1.3em">${s.icon} ${s.name}</div>
                <div style="margin-top:4px">
                    <span style="color:var(--green-bright);font-weight:bold">${estDmg}</span>
                    <span style="color:var(--text-dim)"> (${s.prob}%)</span>
                    ${effectTag}
                </div>
                <div style="font-size:0.7em;color:var(--text-dim)">失败 ~${estFail}</div>
            </button>`;
        }).join('');
        container.style.display = 'flex';
        container.style.gap = '8px';
        container.style.justifyContent = 'center';
        container.style.flexWrap = 'wrap';
        container.style.marginBottom = '12px';
    } catch (err) {
        console.error('Load skills error:', err);
    }
}

async function combatAction(action) {
    if (!activeCharId) return;
    try {
        let result;
        switch (action) {
            case 'defend':
                result = await API.post(`/combat/defend/${activeCharId}`);
                break;
            case 'flee':
                result = await API.post(`/combat/flee/${activeCharId}`);
                break;
            case 'use-potion':
                result = await API.post(`/combat/use-potion/${activeCharId}`);
                break;
        }
        processCombatResult(result);
    } catch (err) {
        addLogLine(`❌ ${err.message}`, 'danger');
    }
}

function processCombatResult(result) {
    // 显示日志
    if (result.log && result.log.length > 0) {
        result.log.forEach(line => addLogLine(line, ''));
    }
    if (result.message) {
        addLogLine(result.message, result.success ? 'highlight' : 'danger');
    }

    // 显示掉落
    if (result.loot && result.loot.length > 0) {
        result.loot.forEach(item => {
            addLogLine(`🎁 获得战利品: ${item.name} [${item.rarity}] +${item.stat_bonus} ${item.item_type === 'weapon' ? '攻击' : '防御'}`, 'loot');
        });
    }

    // 升级通知
    if (result.leveled_up) {
        addLogLine('🆙 升级了！你的力量增强了！', 'highlight');
    }

    // 刷新面板
    refreshCharPanel();

    // 战斗UI + 战后选项
    if (result.character) {
        if (result.character.in_battle && result.character.hp > 0) {
            showBattleUI(result.character);
            postBattleActive = false;
            lastCombatResult = null;
            hidePostBattleOptions();
        } else {
            hideBattleUI();

            // 战斗结束后显示选项
            if (result.character.hp > 0) {
                postBattleActive = true;
                lastCombatResult = result;
                showPostBattleOptions(result);
            }
        }

        // 死亡处理
        if (result.character.hp <= 0) {
            addLogLine('💀 你的角色阵亡了。', 'danger');
            addLogLine('请返回大厅创建新角色。', 'danger');
            document.getElementById('combat-actions').style.display = 'none';
            postBattleActive = false;
            lastCombatResult = null;
            hidePostBattleOptions();
            setTimeout(() => returnToLobby(), 3000);
        }
    }
}

// 战后选项面板
function showPostBattleOptions(result) {
    const container = document.getElementById('post-battle-options');
    container.style.display = 'block';
    postBattleActive = true;

    let html = '<div style="text-align:center;padding:20px;background:var(--bg-card);border:2px solid var(--gold);border-radius:12px;margin-bottom:16px">';
    html += '<h3 style="color:var(--gold-bright);margin-bottom:16px">🎉 战斗胜利！接下来做什么？</h3>';
    html += '<p style="color:var(--text-dim);margin-bottom:14px;font-size:0.9em">💡 查看背包、商店、排行榜后还可以回来继续选择</p>';
    html += '<div style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap">';
    html += '<button class="btn-combat" onclick="postBattleAction(\'explore\')" style="font-size:0.95em">🔍 继续探索</button>';
    html += '<button class="btn-combat" onclick="postBattleAction(\'next-floor\')" style="font-size:0.95em">⬇️ 进入下一层</button>';
    html += '<button class="btn-combat" onclick="postBattleAction(\'shop\')" style="font-size:0.95em">🏪 去商店</button>';
    html += '<button class="btn-combat" onclick="postBattleAction(\'inventory\')" style="font-size:0.95em">🎒 查看背包</button>';
    html += '<button class="btn-combat" onclick="postBattleAction(\'leaderboard\')" style="font-size:0.95em">🏆 排行榜</button>';
    html += '<button class="btn-combat btn-danger" onclick="postBattleAction(\'lobby\')" style="font-size:0.95em">🚪 返回大厅</button>';
    html += '</div></div>';

    container.innerHTML = html;
}

function hidePostBattleOptions() {
    document.getElementById('post-battle-options').style.display = 'none';
}

// 恢复战后选项（从背包/商店/排行榜返回时调用）
function restorePostBattleOptions() {
    if (postBattleActive && lastCombatResult) {
        showPostBattleOptions(lastCombatResult);
    }
}

async function postBattleAction(action) {
    switch (action) {
        case 'explore':
            // 继续探索 → 清除战后状态，触发新遇怪
            postBattleActive = false;
            lastCombatResult = null;
            hidePostBattleOptions();
            addLogLine('🔍 继续探索地牢...', 'highlight');
            try {
                const result = await API.post(`/dungeon/explore/${activeCharId}`);
                processCombatResult(result);
            } catch (err) {
                addLogLine(`❌ ${err.message}`, 'danger');
            }
            break;

        case 'next-floor':
            // 下一层 → 清除战后状态
            postBattleActive = false;
            lastCombatResult = null;
            hidePostBattleOptions();
            addLogLine('⬇️ 向更深处前进...', 'highlight');
            await nextFloor();
            break;

        case 'shop':
            // 去商店 → 保留战后状态，回来还能选
            hidePostBattleOptions();
            navigateTo('shop');
            break;

        case 'inventory':
            // 查看背包 → 保留战后状态，回来还能选
            hidePostBattleOptions();
            navigateTo('inventory');
            break;

        case 'leaderboard':
            // 排行榜 → 保留战后状态，回来还能选
            hidePostBattleOptions();
            navigateTo('leaderboard');
            break;

        case 'lobby':
            // 返回大厅 → 清除战后状态
            postBattleActive = false;
            lastCombatResult = null;
            hidePostBattleOptions();
            returnToLobby();
            break;
    }
}

const INTENT_LABELS = {
    'attack': '⚔️ 普通攻击',
    'heavy': '💥 蓄力重击',
    'defend': '🛡️ 叠甲防御',
    'buff': '⚡ 力量增幅',
    'debuff': '🔮 削弱诅咒',
};

const STATUS_EFFECT_NAMES = {
    'stun': '😵 眩晕（跳过下回合）',
    'vulnerable': '💔 易伤（受到伤害+50%）',
    'poison': '☠️ 中毒（每回合额外掉血）',
    'slow': '🐌 减速（攻击力减半）',
};

function showBattleUI(char) {
    const area = document.getElementById('battle-area');
    area.style.display = 'block';

    const mhpPct = char.battle_monster_hp && char.battle_monster_max_hp
        ? Math.round(char.battle_monster_hp / char.battle_monster_max_hp * 100) : 100;

    const intentLabel = INTENT_LABELS[char.battle_monster_intent] || '';
    const intentHtml = intentLabel
        ? `<p style="color:var(--gold-bright);font-size:1.1em;margin-top:8px;font-weight:bold">👁️ 怪物意图: ${intentLabel}</p>`
        : '';

    let statusHtml = '';
    if (char.battle_monster_status) {
        const statuses = char.battle_monster_status.split(',').filter(Boolean);
        if (statuses.length > 0) {
            statusHtml = '<div style="margin-top:6px">' +
                statuses.map(s => `<span style="display:inline-block;margin:2px;padding:2px 8px;background:var(--bg-dark);border-radius:10px;font-size:0.85em;color:var(--purple-bright)">${STATUS_EFFECT_NAMES[s] || s}</span>`).join('') +
                '</div>';
        }
    }

    document.getElementById('monster-info').innerHTML = `
        <h2>${char.battle_monster_name || '怪物'}</h2>
        <div class="monster-hp"><div class="monster-hp-fill" style="width:${mhpPct}%"></div></div>
        <p>💔 生命: ${char.battle_monster_hp}/${char.battle_monster_max_hp}</p>
        <p style="color:var(--text-dim)">攻击: ${char.battle_monster_attack} | 防御: ${char.battle_monster_defense}</p>
        ${intentHtml}
        ${statusHtml}
    `;
    document.getElementById('combat-actions').style.display = 'flex';
    loadSkills();
}

function hideBattleUI() {
    document.getElementById('battle-area').style.display = 'none';
    document.getElementById('combat-actions').style.display = 'none';
    document.getElementById('skill-buttons').style.display = 'none';
}
