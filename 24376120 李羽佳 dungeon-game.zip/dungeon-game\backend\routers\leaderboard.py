from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from database import get_db
from models import Character, User
from schemas import LeaderboardEntry

router = APIRouter(prefix="/api/leaderboard", tags=["leaderboard"])


@router.get("", response_model=list[LeaderboardEntry])
def leaderboard(limit: int = 20, db: Session = Depends(get_db)):
    chars = (
        db.query(Character)
        .join(User)
        .filter(Character.hp > 0)
        .order_by(Character.level.desc(), Character.dungeon_floor.desc(), Character.gold.desc())
        .limit(limit)
        .all()
    )

    result = []
    for rank, char in enumerate(chars, 1):
        result.append(LeaderboardEntry(
            rank=rank,
            character_name=char.name,
            username=char.user.username,
            char_class=char.char_class,
            level=char.level,
            dungeon_floor=char.dungeon_floor,
            gold=char.gold,
        ))
    return result
