// 地牢模块 — 角色管理、探索
let activeCharId = null;

const CLASS_NAMES = { warrior: '战士', mage: '法师', rogue: '盗贼' };

// 随机名字
const RANDOM_NAMES = [
    '阿拉贡', '甘道夫', '暗影', '雷神', '冰霜', '烈焰',
    '疾风', '铁壁', '龙牙', '星陨', '月刃', '雷霆',
    '夜影', '破晓', '苍穹', '碎星', '幻影', '怒焰',
    '风暴', '霜语', '血牙', '影舞', '圣光', '暗月',
];

function randomName() {
    const adj = RANDOM_NAMES[Math.floor(Math.random() * RANDOM_NAMES.length)];
    const n = Math.floor(Math.random() * 100);
    return adj + n;
}

// --- 角色大厅 ---
async function showLobby() {
    document.getElementById('nav-user').textContent = '⚔️ 冒险者公会';
    showScreen('lobby');

    try {
        const chars = await API.get('/characters/mine');
        const listEl = document.getElementById('char-list');

        if (chars.length === 0) {
            listEl.innerHTML = '<p style="color:var(--text-dim);text-align:center">还没有角色，点击下方按钮快速创建！</p>';
        } else {
            listEl.innerHTML = chars.map(c => {
                const hpPct = Math.round(c.hp / c.max_hp * 100);
                const xpNeeded = c.level * 100;
                const xpPct = Math.round(c.xp / xpNeeded * 100);
                const statusBadge = c.hp <= 0
                    ? '<span style="color:var(--red-bright)">💀 已阵亡</span>'
                    : c.in_battle
                        ? '<span style="color:var(--red-bright)">⚔️ 战斗中！</span>'
                        : '<span style="color:var(--green-bright)">✅ 就绪</span>';
                return `
                <div class="char-card" onclick="selectCharacter(${c.id})">
                    <div>
                        <h3>${c.name} <span class="class-badge class-${c.char_class}">${CLASS_NAMES[c.char_class] || c.char_class}</span></h3>
                        <div class="char-stats-row">
                            <span>📍 第${c.dungeon_floor}层</span>
                            <span>⭐ Lv.${c.level}</span>
                            <span>❤️ ${c.hp}/${c.max_hp}</span>
                            <span>⚔️ ${c.attack}</span>
                            <span>🛡️ ${c.defense}</span>
                            <span>💰 ${c.gold}g</span>
                            ${statusBadge}
                        </div>
                        <div class="hp-bar-bg"><div class="hp-bar-fill" style="width:${hpPct}%"></div></div>
                        <div class="xp-bar-bg"><div class="xp-bar-fill" style="width:${xpPct}%"></div></div>
                    </div>
                    <button class="btn-danger" onclick="event.stopPropagation();deleteCharacter(${c.id})">✕</button>
                </div>`;
            }).join('');
        }
    } catch (err) {
        console.error('Lobby error:', err);
        document.getElementById('char-list').innerHTML = '<p style="color:var(--red-bright);text-align:center">加载失败，请刷新页面</p>';
        if (err.message.includes('401') || err.message.includes('验证')) {
            logout();
        }
    }
}

// 一键创建角色
async function quickCreate(charClass) {
    const name = randomName();
    try {
        await API.post('/characters', { name, char_class: charClass });
        showLobby();
    } catch (err) {
        alert(err.message);
    }
}

async function deleteCharacter(id) {
    if (!confirm('确定要删除这个角色吗？此操作不可撤销！')) return;
    try {
        await API.delete(`/characters/${id}`);
        if (activeCharId === id) activeCharId = null;
        showLobby();
    } catch (err) {
        alert(err.message);
    }
}

// --- 进入游戏 (自动遇怪) ---
async function selectCharacter(id) {
    try {
        const char = await API.get(`/characters/${id}`);
        if (char.hp <= 0) {
            alert('该角色已阵亡，请创建新角色。');
            return;
        }
        activeCharId = id;
        localStorage.setItem('active_char_id', id);
        navigateTo('game');
        hideBattleUI();
        hidePostBattleOptions();
        document.getElementById('game-log').innerHTML = '';

        if (char.in_battle) {
            addLogLine('⚔️ 你正在战斗中！继续作战吧！', 'highlight');
            await refreshCharPanel();
            showBattleUI(char);
        } else {
            addLogLine(`📍 你来到了第${char.dungeon_floor}层。`, 'highlight');
            addLogLine('🔍 正在探索地牢...', '');
            await refreshCharPanel();
            try {
                const result = await API.post(`/dungeon/explore/${activeCharId}`);
                processCombatResult(result);
            } catch (err) {
                addLogLine(`❌ ${err.message}`, 'danger');
            }
        }
    } catch (err) {
        alert(err.message);
    }
}

function returnToLobby() {
    activeCharId = null;
    localStorage.removeItem('active_char_id');
    postBattleActive = false;
    lastCombatResult = null;
    hideBattleUI();
    hidePostBattleOptions();
    document.getElementById('game-log').innerHTML = '';
    showLobby();
}

// --- 地牢操作 ---
async function exploreDungeon() {
    if (!activeCharId) return;
    try {
        hidePostBattleOptions();
        const result = await API.post(`/dungeon/explore/${activeCharId}`);
        processCombatResult(result);
    } catch (err) {
        addLogLine(`❌ ${err.message}`, 'danger');
    }
}

async function nextFloor() {
    if (!activeCharId) return;
    try {
        hidePostBattleOptions();
        const result = await API.post(`/dungeon/next-floor/${activeCharId}`);
        processCombatResult(result);
        if (result.success && !result.character.in_battle) {
            setTimeout(async () => {
                try {
                    const exploreResult = await API.post(`/dungeon/explore/${activeCharId}`);
                    processCombatResult(exploreResult);
                } catch (err) {
                    addLogLine(`❌ ${err.message}`, 'danger');
                }
            }, 800);
        }
    } catch (err) {
        addLogLine(`❌ ${err.message}`, 'danger');
    }
}

// 武器技能描述
const WEAPON_SKILL_INFO = {
    '精铁长剑': [
        {name:'横斩',icon:'⚔️',prob:90,dmg:'x1.0',fail:'x0.3',desc:''},
        {name:'猛击',icon:'💥',prob:50,dmg:'x1.8',fail:'x0.3',desc:''},
        {name:'盾击',icon:'🛡️',prob:55,dmg:'x0.8',fail:'x0.2',desc:'+眩晕'},
    ],
    '学徒法杖': [
        {name:'火球术',icon:'🔥',prob:85,dmg:'x1.0',fail:'x0.3',desc:''},
        {name:'冰霜箭',icon:'❄️',prob:50,dmg:'x1.4',fail:'x0.3',desc:'+减速'},
        {name:'奥术飞弹',icon:'✨',prob:35,dmg:'x2.0',fail:'x0.2',desc:''},
    ],
    '暗影匕首': [
        {name:'刺击',icon:'🗡️',prob:85,dmg:'x1.0',fail:'x0.3',desc:''},
        {name:'要害攻击',icon:'🎯',prob:50,dmg:'x1.6',fail:'x0.3',desc:'+易伤'},
        {name:'致命毒药',icon:'☠️',prob:45,dmg:'x1.2',fail:'x0.2',desc:'+中毒'},
    ],
};

// --- 刷新角色面板 ---
async function refreshCharPanel() {
    if (!activeCharId) return;
    try {
        const [char, inv] = await Promise.all([
            API.get(`/characters/${activeCharId}`),
            API.get(`/inventory/${activeCharId}`),
        ]);
        const xpNeeded = char.level * 100;
        const hpPct = Math.round(char.hp / char.max_hp * 100);
        const xpPct = Math.round(char.xp / xpNeeded * 100);

        // 找装备的武器
        const weapon = inv.find(ci => ci.equipped && ci.item.item_type === 'weapon');
        let weaponHtml = '';
        if (weapon) {
            const atk = char.attack;
            const skills = WEAPON_SKILL_INFO[weapon.item.name] || [
                {name:'普通攻击',icon:'👊',prob:100,dmg:'x1.0',fail:'x0.3',desc:''}
            ];
            weaponHtml = `<div style="margin-top:10px;padding:8px;background:var(--bg-dark);border-radius:6px;font-size:0.82em">
                    <div style="color:var(--gold);margin-bottom:6px">🗡️ ${weapon.item.name} (ATK${atk})</div>`;
            skills.forEach(s => {
                const estDmg = Math.floor(atk * parseFloat((s.dmg||'x1.0').replace('x','')));
                const estFail = Math.floor(atk * parseFloat((s.fail||'x0.3').replace('x','')));
                weaponHtml += `<div style="color:var(--text-dim);padding:2px 0">
                    ${s.icon} ${s.name}
                    <b style="color:var(--green-bright)">~${estDmg}</b>
                    <span style="color:var(--blue-bright)">${s.prob}%</span>
                    ${s.desc ? '<span style="color:var(--purple-bright)">'+s.desc+'</span>' : ''}
                    <span style="color:#555">| 失败~${estFail}</span>
                </div>`;
            });
            weaponHtml += '</div>';
        }

        document.getElementById('char-stats').innerHTML = `
            <h3 style="color:var(--gold);margin-bottom:10px">${char.name}</h3>
            <div class="stat-line"><span class="stat-label">职业</span><span class="stat-value class-${char.char_class}">${CLASS_NAMES[char.char_class] || char.char_class}</span></div>
            <div class="stat-line"><span class="stat-label">等级</span><span class="stat-value">⭐ ${char.level}</span></div>
            <div class="stat-line"><span class="stat-label">生命</span><span class="stat-value">❤️ ${char.hp}/${char.max_hp}</span></div>
            <div class="hp-bar-bg"><div class="hp-bar-fill" style="width:${hpPct}%"></div></div>
            <div class="stat-line"><span class="stat-label">攻击</span><span class="stat-value">⚔️ ${char.attack}</span></div>
            <div class="stat-line"><span class="stat-label">防御</span><span class="stat-value">🛡️ ${char.defense}</span></div>
            <div class="stat-line"><span class="stat-label">金币</span><span class="stat-value">💰 ${char.gold}</span></div>
            <div class="stat-line"><span class="stat-label">层数</span><span class="stat-value">📍 第${char.dungeon_floor}层</span></div>
            <div class="stat-line"><span class="stat-label">经验</span><span class="stat-value">✨ ${char.xp}/${xpNeeded}</span></div>
            <div class="xp-bar-bg"><div class="xp-bar-fill" style="width:${xpPct}%"></div></div>
            ${weaponHtml}
        `;

        return char;
    } catch (err) {
        addLogLine(`错误: ${err.message}`, 'danger');
        return null;
    }
}
