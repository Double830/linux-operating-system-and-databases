"""
种子数据 — 怪物和商店物品（中文版）
"""
from models import Monster, Item
from database import SessionLocal, engine, Base


MONSTERS = [
    # 第1层: 入门 (HP 45-65, ATK 8-12)
    {"name": "绿色史莱姆", "min_floor": 1, "hp": 45, "attack": 8, "defense": 2, "xp_reward": 22, "gold_reward": 12, "emoji": "🟢"},
    {"name": "巨型老鼠", "min_floor": 1, "hp": 55, "attack": 10, "defense": 3, "xp_reward": 28, "gold_reward": 15, "emoji": "🐀"},
    {"name": "哥布林侦察兵", "min_floor": 1, "hp": 65, "attack": 12, "defense": 4, "xp_reward": 38, "gold_reward": 20, "emoji": "👺"},
    # 第3-4层: 进阶 (HP 90-140, ATK 16-20)
    {"name": "骷髅战士", "min_floor": 3, "hp": 90, "attack": 16, "defense": 8, "xp_reward": 65, "gold_reward": 35, "emoji": "💀"},
    {"name": "暗黑法师", "min_floor": 3, "hp": 80, "attack": 22, "defense": 4, "xp_reward": 72, "gold_reward": 40, "emoji": "🧙"},
    {"name": "洞穴巨魔", "min_floor": 4, "hp": 140, "attack": 18, "defense": 12, "xp_reward": 90, "gold_reward": 50, "emoji": "👹"},
    # 第5-6层: 困难 (HP 160-240, ATK 24-30)
    {"name": "火焰元素", "min_floor": 5, "hp": 160, "attack": 24, "defense": 10, "xp_reward": 120, "gold_reward": 70, "emoji": "🔥"},
    {"name": "暗影刺客", "min_floor": 5, "hp": 120, "attack": 30, "defense": 6, "xp_reward": 135, "gold_reward": 80, "emoji": "🗡️"},
    {"name": "石魔像", "min_floor": 6, "hp": 240, "attack": 20, "defense": 24, "xp_reward": 165, "gold_reward": 100, "emoji": "🗿"},
    # 第7-8层: 极难 (HP 270-360, ATK 28-34)
    {"name": "吸血鬼领主", "min_floor": 7, "hp": 270, "attack": 28, "defense": 16, "xp_reward": 220, "gold_reward": 130, "emoji": "🧛"},
    {"name": "巫妖王", "min_floor": 8, "hp": 320, "attack": 32, "defense": 18, "xp_reward": 280, "gold_reward": 170, "emoji": "👑"},
    # 第9-10层: BOSS (HP 400-580, ATK 36-48)
    {"name": "远古巨龙", "min_floor": 9, "hp": 400, "attack": 38, "defense": 26, "xp_reward": 420, "gold_reward": 280, "emoji": "🐉"},
    {"name": "魔王", "min_floor": 10, "hp": 540, "attack": 46, "defense": 32, "xp_reward": 650, "gold_reward": 450, "emoji": "😈"},
]

ITEMS = [
    # 药水 (消耗品)
    {"name": "小型生命药水", "item_type": "potion", "stat_bonus": 35, "price": 15, "rarity": "common",
     "description": "恢复35点生命值"},
    {"name": "生命药水", "item_type": "potion", "stat_bonus": 70, "price": 40, "rarity": "uncommon",
     "description": "恢复70点生命值"},
    {"name": "强效生命药水", "item_type": "potion", "stat_bonus": 140, "price": 100, "rarity": "rare",
     "description": "恢复140点生命值"},
    {"name": "生命之泉", "item_type": "potion", "stat_bonus": 999, "price": 250, "rarity": "epic",
     "description": "完全恢复生命值"},

    # 初始武器（各职业开局自带）
    {"name": "精铁长剑", "item_type": "weapon", "stat_bonus": 6, "price": 45, "rarity": "common",
     "description": "战士初始武器。+6 ATK"},
    {"name": "学徒法杖", "item_type": "weapon", "stat_bonus": 8, "price": 45, "rarity": "common",
     "description": "法师初始武器。+8 ATK"},
    {"name": "暗影匕首", "item_type": "weapon", "stat_bonus": 6, "price": 45, "rarity": "common",
     "description": "盗贼初始武器。+6 ATK"},
    # 商店武器
    {"name": "生锈的铁剑", "item_type": "weapon", "stat_bonus": 3, "price": 20, "rarity": "common",
     "description": "破旧铁剑。+3 ATK"},
    {"name": "寒钢利刃", "item_type": "weapon", "stat_bonus": 10, "price": 140, "rarity": "uncommon",
     "description": "锋利钢刃。+10 ATK"},
    {"name": "烈焰之舌", "item_type": "weapon", "stat_bonus": 16, "price": 320, "rarity": "rare",
     "description": "火焰魔法剑。+16 ATK"},
    {"name": "屠龙宝刀", "item_type": "weapon", "stat_bonus": 24, "price": 750, "rarity": "epic",
     "description": "传说英雄之刃。+24 ATK"},

    # 防具
    {"name": "皮甲", "item_type": "armor", "stat_bonus": 4, "price": 25, "rarity": "common",
     "description": "基础皮革。+4 DEF"},
    {"name": "锁子甲", "item_type": "armor", "stat_bonus": 8, "price": 65, "rarity": "common",
     "description": "金属锁环。+8 DEF"},
    {"name": "板甲", "item_type": "armor", "stat_bonus": 14, "price": 160, "rarity": "uncommon",
     "description": "厚重钢板。+14 DEF"},
    {"name": "附魔法袍", "item_type": "armor", "stat_bonus": 20, "price": 380, "rarity": "rare",
     "description": "魔法长袍。+20 DEF"},
    {"name": "圣盾", "item_type": "armor", "stat_bonus": 30, "price": 850, "rarity": "epic",
     "description": "神圣守护。+30 DEF"},
]


def seed_database():
    """初始化数据库 — 填充怪物和物品数据。"""
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()

    try:
        # 检查是否已经填充过
        if db.query(Monster).count() > 0:
            print("数据库已填充，跳过。")
            return

        # 填充怪物
        for m in MONSTERS:
            db.add(Monster(**m))

        # 填充物品
        for i in ITEMS:
            db.add(Item(**i))

        db.commit()
        print(f"已填充 {len(MONSTERS)} 个怪物和 {len(ITEMS)} 件物品。")
    finally:
        db.close()


if __name__ == "__main__":
    seed_database()
