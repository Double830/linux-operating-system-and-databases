#!/usr/bin/env python3
"""
MCP Server for Dungeon Adventure RPG.
Provides tools for querying game data — leaderboard, characters, monsters, shop items.
Connect this to Claude Code or any MCP client to interact with the game database.
"""
import os
import sys
import json
import asyncio

# Add backend to path for model imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'backend'))

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql://dungeon:dungeon@localhost:5432/dungeon_game"
)

engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(bind=engine)

server = Server("dungeon-game-mcp")


@server.list_tools()
async def list_tools():
    return [
        Tool(
            name="get_leaderboard",
            description="Get the dungeon leaderboard — top players ranked by level, floor, and gold.",
            inputSchema={
                "type": "object",
                "properties": {
                    "limit": {
                        "type": "integer",
                        "description": "Number of entries (default 20, max 50)",
                        "default": 20,
                    }
                },
            },
        ),
        Tool(
            name="get_character_stats",
            description="Get detailed stats for a specific character by ID.",
            inputSchema={
                "type": "object",
                "properties": {
                    "character_id": {
                        "type": "integer",
                        "description": "The character ID to look up",
                    }
                },
                "required": ["character_id"],
            },
        ),
        Tool(
            name="list_monsters",
            description="List all monsters in the dungeon, filtered by minimum floor.",
            inputSchema={
                "type": "object",
                "properties": {
                    "min_floor": {
                        "type": "integer",
                        "description": "Only show monsters appearing at or after this floor (default 1)",
                        "default": 1,
                    }
                },
            },
        ),
        Tool(
            name="list_shop_items",
            description="List all items available in the shop.",
            inputSchema={
                "type": "object",
                "properties": {
                    "item_type": {
                        "type": "string",
                        "enum": ["weapon", "armor", "potion", "all"],
                        "description": "Filter by item type (default: all)",
                        "default": "all",
                    }
                },
            },
        ),
        Tool(
            name="get_game_status",
            description="Get overall game statistics — total players, characters, battles fought.",
            inputSchema={
                "type": "object",
                "properties": {},
            },
        ),
    ]


@server.call_tool()
async def call_tool(name: str, arguments: dict):
    db = SessionLocal()
    try:
        from models import Character, User, Monster, Item, BattleLog

        if name == "get_leaderboard":
            limit = min(arguments.get("limit", 20), 50)
            chars = (
                db.query(Character)
                .join(User)
                .filter(Character.hp > 0)
                .order_by(Character.level.desc(), Character.dungeon_floor.desc())
                .limit(limit)
                .all()
            )
            lines = ["🏆 **Dungeon Leaderboard**", ""]
            for i, c in enumerate(chars, 1):
                medal = ["🥇", "🥈", "🥉"][i - 1] if i <= 3 else f"#{i}"
                lines.append(f"{medal} **{c.name}** ({c.user.username}) — Lv.{c.level} {c.char_class} | Floor {c.dungeon_floor} | 💰{c.gold}g")
            return [TextContent(type="text", text="\n".join(lines))]

        elif name == "get_character_stats":
            cid = arguments["character_id"]
            char = db.query(Character).join(User).filter(Character.id == cid).first()
            if not char:
                return [TextContent(type="text", text=f"❌ Character #{cid} not found.")]
            lines = [
                f"⚔️ **{char.name}** (Player: {char.user.username})",
                f"Class: {char.char_class.upper()} | Level: {char.level} | Floor: {char.dungeon_floor}",
                f"❤️ HP: {char.hp}/{char.max_hp} | ⚔️ ATK: {char.attack} | 🛡️ DEF: {char.defense}",
                f"✨ XP: {char.xp}/{char.level * 100} | 💰 Gold: {char.gold}",
                f"Status: {'💀 Dead' if char.hp <= 0 else ('⚔️ In Battle' if char.in_battle else '✅ Ready')}",
            ]
            if char.in_battle:
                lines.append(f"Fighting: {char.battle_monster_name} (HP: {char.battle_monster_hp}/{char.battle_monster_max_hp})")
            return [TextContent(type="text", text="\n".join(lines))]

        elif name == "list_monsters":
            min_floor = arguments.get("min_floor", 1)
            monsters = db.query(Monster).filter(Monster.min_floor >= min_floor).order_by(Monster.min_floor).all()
            if not monsters:
                return [TextContent(type="text", text=f"No monsters found for floor ≥ {min_floor}.")]
            lines = [f"👾 **Monsters (Floor ≥ {min_floor})**", ""]
            for m in monsters:
                lines.append(f"{m.emoji} **{m.name}** — Appears: Floor {m.min_floor}+ | ❤️{m.hp} ⚔️{m.attack} 🛡️{m.defense} | +{m.xp_reward}XP +{m.gold_reward}g")
            return [TextContent(type="text", text="\n".join(lines))]

        elif name == "list_shop_items":
            item_type = arguments.get("item_type", "all")
            query = db.query(Item).order_by(Item.price)
            if item_type != "all":
                query = query.filter(Item.item_type == item_type)
            items = query.all()
            lines = ["🏪 **Shop Items**", ""]
            for item in items:
                rarity_icon = {"common": "⬜", "uncommon": "🟩", "rare": "🟦", "epic": "🟪"}.get(item.rarity, "")
                lines.append(f"{rarity_icon} **{item.name}** ({item.item_type}) — {item.description} | 💰{item.price}g")
            return [TextContent(type="text", text="\n".join(lines))]

        elif name == "get_game_status":
            total_users = db.query(User).count()
            total_chars = db.query(Character).count()
            alive_chars = db.query(Character).filter(Character.hp > 0).count()
            total_battles = db.query(BattleLog).count()
            wins = db.query(BattleLog).filter(BattleLog.result == "win").count()
            lines = [
                "🎮 **Dungeon Game Status**", "",
                f"👤 Total Players: {total_users}",
                f"⚔️ Total Characters: {total_chars} (Alive: {alive_chars})",
                f"⚡ Battles Fought: {total_battles}",
                f"🎉 Victories: {wins} ({round(wins/total_battles*100, 1) if total_battles else 0}%)",
            ]
            return [TextContent(type="text", text="\n".join(lines))]

        else:
            return [TextContent(type="text", text=f"Unknown tool: {name}")]

    finally:
        db.close()


async def main():
    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, server.create_initialization_options())


if __name__ == "__main__":
    asyncio.run(main())
