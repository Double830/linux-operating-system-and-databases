from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session, joinedload
from database import get_db
from models import User, Character, CharacterItem, Item
from schemas import CharacterItemResponse, ItemResponse, CharacterResponse
from auth import get_current_user

router = APIRouter(prefix="/api/inventory", tags=["inventory"])


@router.get("/{character_id}", response_model=list[CharacterItemResponse])
def get_inventory(character_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    char = _get_character(character_id, user, db)
    items = (
        db.query(CharacterItem)
        .options(joinedload(CharacterItem.item))
        .filter(CharacterItem.character_id == char.id)
        .all()
    )
    return items


@router.post("/equip/{character_id}/{inventory_id}", response_model=CharacterResponse)
def equip_item(character_id: int, inventory_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    char = _get_character(character_id, user, db)
    ci = db.query(CharacterItem).filter(
        CharacterItem.id == inventory_id,
        CharacterItem.character_id == char.id,
    ).first()
    if not ci:
        raise HTTPException(status_code=404, detail="背包中未找到该物品")
    if ci.equipped:
        raise HTTPException(status_code=400, detail="该物品已装备")
    if ci.item.item_type not in ("weapon", "armor"):
        raise HTTPException(status_code=400, detail="只能装备武器和护甲")

    # Unequip any item of same type
    same_type = (
        db.query(CharacterItem)
        .join(Item)
        .filter(
            CharacterItem.character_id == char.id,
            CharacterItem.equipped == True,
            Item.item_type == ci.item.item_type,
        )
        .first()
    )
    if same_type:
        char.attack -= same_type.item.stat_bonus if same_type.item.item_type == "weapon" else 0
        char.defense -= same_type.item.stat_bonus if same_type.item.item_type == "armor" else 0
        same_type.equipped = False

    # Equip new item
    ci.equipped = True
    if ci.item.item_type == "weapon":
        char.attack += ci.item.stat_bonus
    else:
        char.defense += ci.item.stat_bonus

    db.commit()
    db.refresh(char)
    return char


@router.post("/unequip/{character_id}/{inventory_id}", response_model=CharacterResponse)
def unequip_item(character_id: int, inventory_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    char = _get_character(character_id, user, db)
    ci = db.query(CharacterItem).filter(
        CharacterItem.id == inventory_id,
        CharacterItem.character_id == char.id,
        CharacterItem.equipped == True,
    ).first()
    if not ci:
        raise HTTPException(status_code=400, detail="该物品未装备")

    ci.equipped = False
    if ci.item.item_type == "weapon":
        char.attack -= ci.item.stat_bonus
    else:
        char.defense -= ci.item.stat_bonus

    db.commit()
    db.refresh(char)
    return char


def _get_character(character_id: int, user: User, db: Session) -> Character:
    char = db.query(Character).filter(Character.id == character_id, Character.user_id == user.id).first()
    if not char:
        raise HTTPException(status_code=404, detail="角色未找到")
    return char
