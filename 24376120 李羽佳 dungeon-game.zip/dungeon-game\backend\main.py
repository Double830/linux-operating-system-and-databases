from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from database import engine, Base
from seed import seed_database
from routers import auth, characters, dungeon, combat, inventory, shop, leaderboard

app = FastAPI(
    title="地牢冒险 RPG",
    description="基于 FastAPI 构建的交互式地牢探险游戏",
    version="1.0.0",
)

# CORS for local development
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# API routes
app.include_router(auth.router)
app.include_router(characters.router)
app.include_router(dungeon.router)
app.include_router(combat.router)
app.include_router(inventory.router)
app.include_router(shop.router)
app.include_router(leaderboard.router)

@app.get("/api/health")
def health():
    return {"status": "ok", "game": "Dungeon Adventure RPG"}


@app.on_event("startup")
def startup():
    Base.metadata.create_all(bind=engine)
    seed_database()


# Serve frontend static files (must be last)
app.mount("/", StaticFiles(directory="../frontend", html=True), name="frontend")
