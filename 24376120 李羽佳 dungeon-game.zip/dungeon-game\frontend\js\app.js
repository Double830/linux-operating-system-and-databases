// 应用入口 — 自动共享账号登录，直接进入角色大厅
(async function init() {
    const SHARED_USER = 'adventurer';
    const SHARED_PASS = 'dungeon123';

    // 尝试登录共享账号，失败则自动注册
    try {
        const data = await API.post('/auth/login', {
            username: SHARED_USER,
            password: SHARED_PASS,
        });
        localStorage.setItem('token', data.access_token);
        localStorage.setItem('user_id', data.user_id);
        localStorage.setItem('username', data.username);
    } catch (e) {
        // 账号不存在，自动注册
        try {
            const data = await API.post('/auth/register', {
                username: SHARED_USER,
                password: SHARED_PASS,
            });
            localStorage.setItem('token', data.access_token);
            localStorage.setItem('user_id', data.user_id);
            localStorage.setItem('username', data.username);
        } catch (err) {
            document.body.innerHTML = '<h2 style="color:red;text-align:center;margin-top:100px">无法连接到服务器，请确认服务已启动</h2>';
            return;
        }
    }

    document.getElementById('nav-user').textContent = '⚔️ 冒险者公会';
    showLobby();
})();
