from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Boolean, func
from sqlalchemy.orm import relationship
from database import Base


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(50), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    characters = relationship("Character", back_populates="user", cascade="all, delete-orphan")


class Character(Base):
    __tablename__ = "characters"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    name = Column(String(50), nullable=False)
    char_class = Column(String(20), nullable=False)  # warrior, mage, rogue
    level = Column(Integer, default=1)
    xp = Column(Integer, default=0)
    hp = Column(Integer, default=100)
    max_hp = Column(Integer, default=100)
    attack = Column(Integer, default=15)
    defense = Column(Integer, default=10)
    gold = Column(Integer, default=50)
    dungeon_floor = Column(Integer, default=1)
    in_battle = Column(Boolean, default=False)
    battle_monster_name = Column(String(50), nullable=True)
    battle_monster_hp = Column(Integer, nullable=True)
    battle_monster_max_hp = Column(Integer, nullable=True)
    battle_monster_attack = Column(Integer, nullable=True)
    battle_monster_defense = Column(Integer, nullable=True)
    battle_monster_xp = Column(Integer, nullable=True)
    battle_monster_gold = Column(Integer, nullable=True)
    battle_monster_intent = Column(String(30), nullable=True)  # attack/heavy_attack/defend/buff/debuff/heal
    battle_monster_status = Column(String(50), nullable=True)  # stun/vulnerable/poison/slow (comma-separated)

    user = relationship("User", back_populates="characters")
    items = relationship("CharacterItem", back_populates="character", cascade="all, delete-orphan")
    battle_logs = relationship("BattleLog", back_populates="character", cascade="all, delete-orphan")


class Item(Base):
    __tablename__ = "items"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(50), nullable=False)
    item_type = Column(String(20), nullable=False)  # weapon, armor, potion
    stat_bonus = Column(Integer, default=0)
    price = Column(Integer, default=10)
    rarity = Column(String(10), default="common")  # common, uncommon, rare, epic
    description = Column(String(200), default="")


class CharacterItem(Base):
    __tablename__ = "character_items"

    id = Column(Integer, primary_key=True, index=True)
    character_id = Column(Integer, ForeignKey("characters.id"), nullable=False)
    item_id = Column(Integer, ForeignKey("items.id"), nullable=False)
    equipped = Column(Boolean, default=False)
    quantity = Column(Integer, default=1)

    character = relationship("Character", back_populates="items")
    item = relationship("Item")


class Monster(Base):
    __tablename__ = "monsters"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(50), nullable=False)
    min_floor = Column(Integer, default=1)
    hp = Column(Integer, default=50)
    attack = Column(Integer, default=10)
    defense = Column(Integer, default=5)
    xp_reward = Column(Integer, default=30)
    gold_reward = Column(Integer, default=20)
    emoji = Column(String(10), default="👾")


class BattleLog(Base):
    __tablename__ = "battle_logs"

    id = Column(Integer, primary_key=True, index=True)
    character_id = Column(Integer, ForeignKey("characters.id"), nullable=False)
    monster_name = Column(String(50), nullable=False)
    result = Column(String(10), nullable=False)  # win, lose, flee
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    character = relationship("Character", back_populates="battle_logs")
