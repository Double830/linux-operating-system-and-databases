# 🏰 地牢冒险 RPG

基于 Python FastAPI + PostgreSQL + Docker 的浏览器交互式地牢探险游戏。

## 🚀 快速启动

```bash
cd dungeon-game
docker compose up -d
# 浏览器打开 http://localhost:8080
```

所有人共用账号，打开即玩，无需注册登录。

## 🎮 游戏特色

### 三大职业
| 职业 | HP | 特点 |
|------|-----|------|
| ⚔️ 战士 | 125 | 坦克型前排，防御高，生存力强 |
| 🔮 法师 | 65 | 最高输出，玻璃大炮，需要保护 |
| 🗡️ 盗贼 | 90 | 均衡型，20%暴击率 |

### 武器技能系统
- 每个职业开局自带专属武器
- 3个可选技能，各有成功率和效果
- 成功/失败双判定：成功高伤害+效果，失败轻伤
- 状态效果：眩晕(跳过回合)、易伤(受伤+50%)、中毒(持续掉血)、减速(攻击减半)

### 地牢探索
- 10层地牢，难度递增，13种怪物
- 怪物有AI意图系统（普通攻击/重击/防御/增益/减益）
- 6种随机事件：怪物(50%)、宝箱(15%)、陷阱(10%)、恢复之泉(10%)、神秘商人(8%)、神龛(7%)
- 战斗胜利可掉落装备

### 装备系统
- 武器/护甲/药水三大类
- 稀有度：普通/罕见/稀有/史诗
- 商店购买，背包装备/卸下

### 战后选项
- 胜利后弹出6个选项面板
- 查看背包、去商店、排行榜后可以回来继续选
- 只有继续探索或下一层才会消耗选项

## 🛠️ 技术栈

| 层级 | 技术 |
|------|------|
| 后端框架 | Python FastAPI |
| 数据库 | PostgreSQL 16 |
| ORM | SQLAlchemy |
| 认证 | JWT (python-jose + bcrypt) |
| 前端 | 原生 HTML/CSS/JS (SPA) |
| 容器化 | Docker Compose |
| MCP | 可选 MCP 服务器 |

## 📂 项目结构

```
dungeon-game/
├── docker-compose.yml          # Docker编排
├── Dockerfile                  # 应用容器
├── requirements.txt            # Python依赖
├── README.md
├── backend/
│   ├── main.py                 # FastAPI入口
│   ├── config.py               # 环境配置
│   ├── database.py             # SQLAlchemy连接
│   ├── models.py               # ORM模型 (7张表)
│   ├── schemas.py              # Pydantic校验
│   ├── auth.py                 # JWT认证
│   ├── seed.py                 # 种子数据 (13怪物+16物品)
│   └── routers/
│       ├── auth.py             # 登录/注册
│       ├── characters.py       # 角色管理
│       ├── dungeon.py          # 探索+事件系统
│       ├── combat.py           # 战斗+技能系统
│       ├── inventory.py        # 背包装备管理
│       ├── shop.py             # 商店
│       └── leaderboard.py      # 排行榜
├── frontend/
│   ├── index.html              # SPA页面
│   ├── css/style.css           # 暗黑地牢风格
│   └── js/
│       ├── app.js              # 自动登录
│       ├── api.js              # HTTP客户端
│       ├── auth.js             # 认证
│       ├── dungeon.js          # 角色面板+探索
│       ├── combat.js           # 战斗UI+技能按钮
│       └── ui.js               # 导航+背包/商店/排行
└── mcp-server/
    ├── server.py               # MCP服务器
    └── requirements.txt
```

## 📡 API 接口

```
POST /api/auth/register         注册
POST /api/auth/login            登录

GET  /api/characters/classes    职业列表
POST /api/characters            创建角色
GET  /api/characters/mine       我的角色
DELETE /api/characters/{id}     删除角色

GET  /api/dungeon/status/{id}   地牢状态
POST /api/dungeon/explore/{id}  探索 (随机事件)
POST /api/dungeon/next-floor/{id} 下一层

GET  /api/combat/skills/{id}    武器技能列表
POST /api/combat/attack/{id}    攻击 (选技能)
POST /api/combat/defend/{id}    防御
POST /api/combat/flee/{id}      逃跑
POST /api/combat/use-potion/{id} 使用药水

GET  /api/inventory/{id}        背包
POST /api/inventory/equip/{id}/{inv}   装备
POST /api/inventory/unequip/{id}/{inv} 卸下

GET  /api/shop                  商店
POST /api/shop/buy/{id}/{item}  购买

GET  /api/leaderboard           排行榜
GET  /api/health                健康检查
```

## 🔧 MCP 服务器 (可选)

```bash
cd mcp-server
pip install -r requirements.txt
python server.py
```

提供工具: get_leaderboard, get_character_stats, list_monsters, list_shop_items, get_game_status
