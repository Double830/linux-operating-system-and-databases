import os

DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql://dungeon:dungeon@localhost:5432/dungeon_game"
)

SECRET_KEY = os.getenv("SECRET_KEY", "super-secret-dungeon-key")
JWT_ALGORITHM = os.getenv("JWT_ALGORITHM", "HS256")
JWT_EXPIRE_MINUTES = int(os.getenv("JWT_EXPIRE_MINUTES", "1440"))
