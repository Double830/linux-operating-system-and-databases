// 认证模块 — 保留 logout 供 showLobby 错误处理使用
function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user_id');
    localStorage.removeItem('username');
    localStorage.removeItem('active_char_id');
    // 刷新页面回到初始状态
    location.reload();
}
