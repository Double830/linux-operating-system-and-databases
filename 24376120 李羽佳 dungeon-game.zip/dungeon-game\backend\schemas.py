from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime


# --- Auth ---
class UserRegister(BaseModel):
    username: str = Field(..., min_length=3, max_length=50)
    password: str = Field(..., min_length=4, max_length=100)


class UserLogin(BaseModel):
    username: str
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user_id: int
    username: str


# --- Character ---
class CharacterCreate(BaseModel):
    name: str = Field(..., min_length=2, max_length=50)
    char_class: str = Field(..., pattern="^(warrior|mage|rogue)$")


class CharacterResponse(BaseModel):
    id: int
    user_id: int
    name: str
    char_class: str
    level: int
    xp: int
    hp: int
    max_hp: int
    attack: int
    defense: int
    gold: int
    dungeon_floor: int
    in_battle: bool
    battle_monster_name: Optional[str] = None
    battle_monster_hp: Optional[int] = None
    battle_monster_max_hp: Optional[int] = None
    battle_monster_attack: Optional[int] = None
    battle_monster_defense: Optional[int] = None
    battle_monster_xp: Optional[int] = None
    battle_monster_gold: Optional[int] = None
    battle_monster_intent: Optional[str] = None
    battle_monster_status: Optional[str] = None

    class Config:
        from_attributes = True


# --- Item ---
class ItemResponse(BaseModel):
    id: int
    name: str
    item_type: str
    stat_bonus: int
    price: int
    rarity: str
    description: str

    class Config:
        from_attributes = True


class CharacterItemResponse(BaseModel):
    id: int
    item: ItemResponse
    equipped: bool
    quantity: int

    class Config:
        from_attributes = True


# --- Combat ---
class CombatAction(BaseModel):
    character_id: int


class AttackAction(BaseModel):
    skill_index: int = 0  # 0=技能1, 1=技能2, 2=技能3


class CombatResult(BaseModel):
    success: bool
    message: str
    log: List[str] = []
    character: Optional[CharacterResponse] = None
    loot: Optional[List[ItemResponse]] = None
    leveled_up: bool = False


# --- Dungeon ---
class DungeonStatus(BaseModel):
    floor: int
    in_battle: bool
    monster: Optional[dict] = None


# --- Shop ---
class ShopBuy(BaseModel):
    character_id: int
    item_id: int


# --- Leaderboard ---
class LeaderboardEntry(BaseModel):
    rank: int
    character_name: str
    username: str
    char_class: str
    level: int
    dungeon_floor: int
    gold: int


# --- Battle Log ---
class BattleLogResponse(BaseModel):
    id: int
    monster_name: str
    result: str
    created_at: datetime

    class Config:
        from_attributes = True
