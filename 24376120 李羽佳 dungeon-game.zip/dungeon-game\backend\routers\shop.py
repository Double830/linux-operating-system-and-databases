from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from database import get_db
from models import User, Character, Item, CharacterItem
from schemas import ItemResponse, CharacterResponse
from auth import get_current_user

router = APIRouter(prefix="/api/shop", tags=["shop"])


@router.get("", response_model=list[ItemResponse])
def shop_items(db: Session = Depends(get_db)):
    return db.query(Item).order_by(Item.price).all()


@router.post("/buy/{character_id}/{item_id}", response_model=CharacterResponse)
def buy_item(character_id: int, item_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    char = db.query(Character).filter(Character.id == character_id, Character.user_id == user.id).first()
    if not char:
        raise HTTPException(status_code=404, detail="角色未找到")

    item = db.query(Item).filter(Item.id == item_id).first()
    if not item:
        raise HTTPException(status_code=404, detail="物品未找到")

    if char.gold < item.price:
        raise HTTPException(status_code=400, detail=f"金币不足！需要 {item.price}，当前拥有 {char.gold}")

    char.gold -= item.price

    # Add to inventory
    existing = db.query(CharacterItem).filter(
        CharacterItem.character_id == char.id,
        CharacterItem.item_id == item.id,
    ).first()

    if existing:
        existing.quantity += 1
    else:
        db.add(CharacterItem(character_id=char.id, item_id=item.id, quantity=1))

    db.commit()
    db.refresh(char)
    return char
